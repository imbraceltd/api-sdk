export interface Board {
  object_name?: string
  id: string
  organization_id: string
  name: string
  description?: string
  workflow_id?: string
  hidden?: boolean
  team_ids?: string[]
  created_at: string
  updated_at: string
}

export interface BoardItem {
  object_name?: string
  id: string
  board_id: string
  fields: Record<string, unknown>
  created_at: string
  updated_at: string
}

export interface UpdateBoardInput {
  name?: string
  description?: string
  [key: string]: unknown
}

export interface ReorderBoardsInput {
  order: string[]
  [key: string]: unknown
}

export interface ReorderBoardsResponse {
  success: boolean
  [key: string]: unknown
}

export interface ImportResponse {
  success: boolean
  imported?: number
  errors?: unknown[]
  [key: string]: unknown
}

export interface ImportProgressResponse {
  status: string
  progress?: number
  total?: number
  [key: string]: unknown
}

export interface BoardField {
  _id: string
  name: string
  type: string
  options?: unknown[]
  required?: boolean
  [key: string]: unknown
}

export interface CreateFieldInput {
  name: string
  type: string
  options?: unknown[]
  required?: boolean
  [key: string]: unknown
}

export interface UpdateFieldInput {
  name?: string
  options?: unknown[]
  required?: boolean
  [key: string]: unknown
}

export interface ReorderFieldsInput {
  fields: string[]
  [key: string]: unknown
}

export interface BulkUpdateFieldsInput {
  fields: Partial<BoardField>[]
  [key: string]: unknown
}

export interface FieldOperationResponse {
  success: boolean
  field?: BoardField
  [key: string]: unknown
}

export interface CreateItemInput {
  [key: string]: unknown
}

export interface UpdateItemInput {
  [key: string]: unknown
}

export interface BulkDeleteItemsInput {
  ids: string[]
  [key: string]: unknown
}

export interface BulkDeleteItemsResponse {
  success: boolean
  deleted?: number
  [key: string]: unknown
}

export interface CheckConflictInput {
  version?: number
  [key: string]: unknown
}

export interface LinkItemsInput {
  related_item_ids: string[]
  [key: string]: unknown
}

export interface LinkItemsResponse {
  success: boolean
  [key: string]: unknown
}

export interface BoardSegment {
  _id: string
  name: string
  filter?: Record<string, unknown>
  [key: string]: unknown
}

export interface CreateSegmentInput {
  name: string
  filter?: Record<string, unknown>
  [key: string]: unknown
}

export interface UpdateSegmentInput {
  name?: string
  filter?: Record<string, unknown>
  [key: string]: unknown
}

export interface KnowledgeFolder {
  _id: string
  name: string
  organization_id?: string
  parent_id?: string
  [key: string]: unknown
}

export interface CreateFolderInput {
  name: string
  organization_id?: string
  parent_id?: string
  [key: string]: unknown
}

export interface UpdateFolderInput {
  name?: string
  [key: string]: unknown
}

export interface DeleteFoldersInput {
  ids: string[]
  [key: string]: unknown
}

export interface DeleteFoldersResponse {
  success: boolean
  deleted?: number
  [key: string]: unknown
}

export interface KnowledgeFile {
  _id: string
  name: string
  folder_id?: string
  url?: string
  size?: number
  [key: string]: unknown
}

export interface CreateFileInput {
  name: string
  folder_id?: string
  content?: string
  [key: string]: unknown
}

export interface UpdateFileInput {
  name?: string
  content?: string
  [key: string]: unknown
}

export interface DeleteFilesInput {
  ids: string[]
  [key: string]: unknown
}

export interface DeleteFilesResponse {
  success: boolean
  deleted?: number
  [key: string]: unknown
}

export interface UploadFileResponse {
  url: string
  file_id?: string
  [key: string]: unknown
}

export interface AiTagsInput {
  file_id?: string
  text?: string
  [key: string]: unknown
}
