import { HttpTransport } from "../http.js"

// ── Types ─────────────────────────────────────────────────────────────────────

export interface DocumentAIAgent {
  _id?: string
  id?: string
  name: string
  agent_type?: string
  model_id?: string
  provider_id?: string
  instructions?: string
  data_schema?: Record<string, unknown>
  workflow_name?: string
  description?: string
  created_at?: string
  updated_at?: string
  [key: string]: unknown
}

export interface CreateDocumentAIAgentInput {
  /** Display name shown in UI (e.g. "Receipt Extractor"). */
  name: string
  /** System prompt governing extraction logic. */
  instructions: string
  /** LLM model id (e.g. "gpt-4o" for system provider, or model id of a custom provider). */
  model_id: string
  /** Provider id. Use "system" for org default, or a custom provider UUID. */
  provider_id?: string
  /** Internal workflow name (defaults to "document_extraction"). */
  workflow_name?: string
  /**
   * JSON schema for fields to extract. Stored as `data_schema` on backend.
   * @example { invoice_number: { type: "string" }, total: { type: "number" } }
   */
  schema?: Record<string, unknown>
  description?: string
  [key: string]: unknown
}

export interface UpdateDocumentAIAgentInput {
  name?: string
  instructions?: string
  model_id?: string
  provider_id?: string
  workflow_name?: string
  schema?: Record<string, unknown>
  description?: string
  [key: string]: unknown
}

export interface ProcessDocumentInput {
  /** URL of the PDF/image to extract. */
  url: string
  /** Organization id (sent in body and header). */
  organizationId: string
  /**
   * If provided, agent's `model_id` and `instructions` are looked up and used
   * unless `modelName`/`instructions` are also provided (which override).
   */
  agentId?: string
  /** Override or replace agent's model. Required if `agentId` not provided. */
  modelName?: string
  /** Override or replace agent's instructions. */
  instructions?: string
  boardId?: string
  language?: string
  additionalDocumentInstructions?: string
  utc?: number
  chunkSize?: number
  maxConcurrent?: number
  maxRetries?: number
  useEnhancedProcessing?: boolean
  [key: string]: unknown
}

export interface ProcessDocumentResponse {
  success: boolean
  data: Record<string, unknown> & { filledPdfUrl?: string }
  [key: string]: unknown
}

// ── Resource ──────────────────────────────────────────────────────────────────

/**
 * Document AI — high-level wrapper for the iMBRACE Document AI Agent feature.
 *
 * **What is a Document AI Agent?** A specialized AI Assistant configured to
 * extract structured JSON from unstructured documents (PDFs, images, scanned
 * forms). Each agent has:
 * - a **schema** defining the fields to extract
 * - **instructions** guiding the LLM (business rules, formats)
 * - a **model** + **provider** for the underlying VLM/LLM
 * - optional **workflow** integration for automation
 *
 * Under the hood this resource wraps the AI Assistant CRUD endpoints with
 * `agent_type: "document_ai"` filtering, plus the document processing endpoint
 * `/v3/ai/document/`.
 *
 * @example Create + use an agent
 * ```ts
 * // Setup once
 * const agent = await client.documentAi.createAgent({
 *   name: "Invoice Extractor",
 *   instructions: "Extract invoice fields. Dates as YYYY-MM-DD.",
 *   model_id: "gpt-4o",
 *   schema: {
 *     invoice_number: { type: "string", description: "Invoice ID" },
 *     total:          { type: "number" },
 *     date:           { type: "string", format: "date" },
 *   },
 * })
 *
 * // Use many times
 * const result = await client.documentAi.process({
 *   agentId: agent._id!,
 *   url: "https://example.com/invoice.pdf",
 *   organizationId: "org_xxx",
 * })
 * ```
 */
export class DocumentAIResource {
  /**
   * @param http  shared HTTP transport
   * @param aiBase  AI service base ending with `/v3/ai` (same as ChatAI / AI resources)
   */
  constructor(
    private readonly http: HttpTransport,
    private readonly aiBase: string,
  ) {}

  private get base() {
    return this.aiBase.replace(/\/$/, "")
  }

  // ── Agent CRUD ─────────────────────────────────────────────────────────────

  /**
   * List AI Assistants. Optional `nameContains` filter (case-insensitive).
   *
   * Note: backend currently does not formally categorize "Document AI Agent" —
   * every agent has `agent_type: "agent"`. Use `nameContains` to filter by
   * naming convention (e.g. `"receipt"`, `"document"`, `"extract"`).
   */
  async listAgents(opts?: { nameContains?: string }): Promise<DocumentAIAgent[]> {
    const res: any = await this.http.getFetch()(`${this.base}/accounts/assistants`, { method: "GET" })
      .then(r => r.json())
    const all: DocumentAIAgent[] = Array.isArray(res) ? res : (res?.data ?? [])
    if (opts?.nameContains) {
      const kw = opts.nameContains.toLowerCase()
      return all.filter(a => (a.name ?? "").toLowerCase().includes(kw))
    }
    return all
  }

  /** Get a single Document AI Agent by id. */
  async getAgent(agentId: string): Promise<DocumentAIAgent> {
    return this.http.getFetch()(`${this.base}/accounts/assistants/${agentId}`, { method: "GET" })
      .then(r => r.json())
  }

  /**
   * Create a Document AI Agent. Wraps `POST /v3/ai/assistant_apps` with
   * `agent_type: "document_ai"`. Pass `schema` to define the extraction fields.
   */
  async createAgent(input: CreateDocumentAIAgentInput): Promise<DocumentAIAgent> {
    const { schema, ...rest } = input
    const body: Record<string, unknown> = {
      ...rest,
      provider_id: input.provider_id ?? "system",
      workflow_name: input.workflow_name ?? "document_extraction",
    }
    if (schema !== undefined) body.data_schema = schema
    return this.http.getFetch()(`${this.base}/assistant_apps`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    }).then(r => r.json())
  }

  /** Partial update — wraps `PUT /v3/ai/assistant_apps/{id}`. */
  async updateAgent(agentId: string, input: UpdateDocumentAIAgentInput): Promise<DocumentAIAgent> {
    const { schema, ...rest } = input
    const body: Record<string, unknown> = { ...rest }
    if (schema !== undefined) body.data_schema = schema
    return this.http.getFetch()(`${this.base}/assistant_apps/${agentId}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    }).then(r => r.json())
  }

  /** Delete an agent. */
  async deleteAgent(agentId: string): Promise<void> {
    await this.http.getFetch()(`${this.base}/assistant_apps/${agentId}`, { method: "DELETE" })
  }

  // ── Process ────────────────────────────────────────────────────────────────

  /**
   * Process a document through a configured agent (or with explicit model/instructions).
   *
   * If `agentId` is given, the agent's `model_id` and `instructions` are loaded
   * unless `modelName`/`instructions` are also passed (which take precedence).
   *
   * Routes to `POST /v3/ai/document/`.
   */
  async process(input: ProcessDocumentInput): Promise<ProcessDocumentResponse> {
    let modelName = input.modelName
    let instructions = input.instructions

    if (input.agentId && (!modelName || !instructions)) {
      const agent = await this.getAgent(input.agentId)
      modelName    = modelName    ?? (agent.model_id as string | undefined)
      instructions = instructions ?? (agent.instructions as string | undefined)
    }

    if (!modelName) {
      throw new Error(
        "documentAi.process: must provide either `agentId` or `modelName`. " +
        "If you passed `agentId` but it has no `model_id` set, pass `modelName` explicitly."
      )
    }

    const reservedKeys = new Set(["url", "organizationId", "agentId", "modelName", "instructions"])
    const body: Record<string, unknown> = {
      modelName,
      url: input.url,
      organizationId: input.organizationId,
    }
    if (instructions) body.additionalInstructions = instructions
    for (const [k, v] of Object.entries(input)) {
      if (!reservedKeys.has(k) && v !== undefined) body[k] = v
    }

    return this.http.getFetch()(`${this.base}/document`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    }).then(r => r.json())
  }

  // ── Schema auto-learn (provisional) ────────────────────────────────────────

  /**
   * Suggest a JSON schema by analyzing a sample document.
   *
   * **Provisional**: this currently uses `process()` with a meta-prompt asking
   * the vision model to propose a schema. If/when the backend exposes a
   * dedicated endpoint (e.g. `/v3/ai/document/auto-schema`), this method will
   * be updated to call it directly. The signature is stable.
   */
  async suggestSchema(input: {
    url: string
    organizationId: string
    modelName?: string
  }): Promise<ProcessDocumentResponse> {
    const metaPrompt =
      "Analyze this document and propose a JSON schema describing the fields. " +
      "Return ONLY a JSON object where each key is a field name and the value " +
      "is { type: <string|number|boolean|date>, description: <short description> }. " +
      "Example: { \"invoice_number\": { \"type\": \"string\", \"description\": \"Invoice ID\" } }"
    return this.process({
      url: input.url,
      organizationId: input.organizationId,
      modelName: input.modelName ?? "gpt-4o",
      instructions: metaPrompt,
    })
  }
}
